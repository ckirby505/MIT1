/**
 * 
 */

package mit1;


import java.awt.Menu;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import ij.*;
import ij.io.Opener;
import ij.plugin.filter.*;
import ij.process.*;
import java.awt.*;

import mit1.Hough_Circles;
import mit1.ImageTools;
import mit1.Contours;
import mit1.ImageToByteArray;

//you will need to include the jar file for OpenCV in your Java Build Path

/**
 * @author kirby
 *
 * Documentation for ImageJ: http://imagejdocu.tudor.lu/doku.php?id=gui:start
 * 							 https://imagej.nih.gov/ij/docs/guide/
 * 							 https://imagej.nih.gov/ij/developer/api/index.html
 *					(edges)  https://imagej.nih.gov/ij/developer/api/index.html
 *					(Hough)	 https://imagej.nih.gov/ij/plugins/download/Hough_Circles.java	
 *
 *
 *Documentation for OpenCV:  https://docs.opencv.org/3.0-beta/doc/py_tutorials/py_imgproc/py_contours/py_contours_begin/py_contours_begin.html#contours-getting-started
 *	(For installing OpenCV)  https://media.readthedocs.org/pdf/opencv-java-tutorials/latest/opencv-java-tutorials.pdf
 *
 *
 */
public class RemoveDimes {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		String file_path = "/Users/kirby/Downloads/";
		
		String img_1 = "coins.jpg";
		String img_2 = "new.jpg";
		
		BufferedImage img = null;
		try {
		    img = ImageIO.read(new File(file_path+img_1));//still need to make this relative to the project folder 
		} catch (IOException e) {
		}
		
		//ImageJ ij 			= new ImageJ();
		
		Filters ij_filter 					= new Filters();
		ColorProcessor ij_color_processor 	= new ColorProcessor(img);
		
		ij_color_processor.findEdges();
		
		BufferedImage buffered_image =  ij_color_processor.getBufferedImage();
		
		//write processed image
		ImageIO.write(buffered_image, "jpg", new File(file_path+img_2));
		
		
		
		
		ImageTools image_tools 		= new ImageTools();
		//image_tools.convertImageToByteArray(file_path+img_2);
		//byte[] image_byte_array 	= image_tools.extractBytes(file_path+img_2);
		 
		ImageToByteArray image_byte_array = new ImageToByteArray();
		try {
			byte[] img_bytes = image_byte_array.getByteArray(file_path+img_2);
			
			Hough_Circles hough_circles = new Hough_Circles();
			
			hough_circles.drawCircles(img_bytes);
			
			Point[] center_points 		= hough_circles.centerPoint;
			System.out.println("center_points: " + center_points.length);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		

		//System.out.println("imag_byte_araay: " + image_byte_array);
		
		//Point[] center_points 		= hough_circles.centerPoint;
		//System.out.println("center_points length: " + center_points.length);
		
		//for (int i=0; i<center_points.length; i++) {
		//	Point current_point = center_points[i];
			
		//	System.out.println("(x,y) = ("+current_point.x+", "+current_point.y);
		//}
		
		
		System.out.println("End");
	      
	}
	
	
	

}

