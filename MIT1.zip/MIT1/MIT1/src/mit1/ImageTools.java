package mit1;

import java.io.ByteArrayOutputStream;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class ImageTools {

	private int threshold = -5000;
	private byte[][] image_bytes;
	
	
	
	
	
}
