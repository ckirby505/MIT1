/**
 * 
 */
package mit1;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import mit1.BoundingBox;

/**
 * @author kirby
 *
 *For determining and quantifying contours in an image
 *
 */
public class Contours {
	
	private String img_path;
	private BufferedImage image;
	private int image_height;
	private int image_width;
	private int threshold = -5000;
	
	
	
	
	
	
	
	
	
	//each row is a contour we've found in the image
	private int[] contours;
	
	//we know these aren't circumference pixels so we won't revisit them
	private int[] non_object_edge_pixels;
	
	private int centroid_x;//for the centroid of an object
	private int centroid_y;
	
	
	
	public void loadImage(String img_path) {
		
		this.img_path = img_path;
		
		try {
			   File f = new File(this.img_path);
			   this.image 			= ImageIO.read(f);
			   this.image_height 	= this.image.getHeight();
			   this.image_width 	= this.image.getWidth();
			   
		} catch (IOException ioe) {
			   ioe.printStackTrace();
		}
	}
	
	
	public void createContourVectors() {
		//sample every object pixel in the image and determine if it's part of a circumference.
		
		int current_x = 0;
		int current_y = 0;
		
		
		
		for (int x=0; x < this.image_width; x++) {
			
			for (int y=0; y < this.image_height; y++) {
				
				int current_pixel = this.image.getRGB(x, y);
				
				
				
				
				if (current_pixel >= this.threshold) {
					//the current pixel is an object pixel, now, is it a circumference pixel?
					
					System.out.println("current_pixel: " + current_pixel);
					System.out.println(x+", "+y);
					
					//let's check the pixels to the north, south, east, and west
					
					int pixel_north = this.image.getRGB(x, y+1);
					int pixel_south = this.image.getRGB(x, y-1);
					int pixel_east 	= this.image.getRGB(x+1, y);
					int pixel_west 	= this.image.getRGB(x-1, y);
					
					boolean crawling_pixels = true;
					
					int crawling_x 	= x;
					int crawling_y 	= y+1;
					
					while (crawling_pixels) {
						
						
						
						
						
						
						
						if (pixel_north > this.threshold) {
							//move to the north and explore
						}
						
						if (pixel_south > this.threshold) {
							//move to the south and explore
						}
						
						if (pixel_east > this.threshold) {
							//move to the east and explore
						}
						
						if (pixel_west > this.threshold) {
							//move to the west and explore
						}
						
						
						//are you traveling in a circle? If not, end the scouting
						
					}
				}
				
				
			}
		}
	}
	
	
	
		
		
	
	
	
	
	
	
}
