/**
 * 
 */
package mit1;

/**
 * @author kirby
 *
 */
import java.io.ByteArrayOutputStream;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

public class ImageToByteArray {
  
	public byte[] getByteArray(String file_name) throws Exception{
      
		BufferedImage bImage = ImageIO.read(new File(file_name));
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ImageIO.write(bImage, "jpg", bos );
		
		byte [] data = bos.toByteArray();
		
		return data;
   }
	
}