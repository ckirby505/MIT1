/**
 * 
 */
package mit1;

/**
 * @author kirby
 *
 */
public class BoundingBox {

}
